package parkinglot;

public class Manager {
	static int ticketCounter = 1;

	Manager() {

	}

	public int getTicketCounter() {
		return ticketCounter;
	}

	public void setTicketCounter(int ticketCounter) {
		this.ticketCounter = ticketCounter;
	}

}
