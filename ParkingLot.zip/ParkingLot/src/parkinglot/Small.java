package parkinglot;

import java.util.Scanner;

public class Small {

	static int countSmall = 1;

	Parking park = new Parking();
	Medium med = new Medium();
	Large large = new Large();
	Main main = new Main();

	public Small() {
	}

	public boolean generateTicketForSmall() {
		park.setCarSize("Small");
		if (Small.countSmall >= 1) {
			park.createParker();
			Small.countSmall -= 1;
			return true;
		} else
			return false;
	}

	public void upgradeSmall() {
		if (Medium.countMedium >= 1) {
			med.generateTicketForMedium();
		} else if (Large.countLarge >= 1) {
			large.generateTicketForLarge();
		} else {
			System.out.println("Sorry Medium/Large also full");
		}
	}
}
