package parkinglot;

import java.text.ParseException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class Parking {
	static List<Parking> parkers = new ArrayList<Parking>();
	private String carSize;
	private int ticketNumber;
	private LocalTime checkinTime;
	private String parkSize;
	private LocalTime checkoutTime;

	public List<Parking> getParkers() {
		return parkers;
	}

	public void setParkers(List<Parking> parkers) {
		this.parkers = parkers;
	}

	public void addParker(Parking parker) {
		parkers.add(parker);
	}

	public String getCarSize() {
		return carSize;
	}

	public void setCarSize(String carSize) {
		this.carSize = carSize;
	}

	public int getTicketNumber() {
		return ticketNumber;
	}

	public void setTicketNumber(int ticketNumber) {
		this.ticketNumber = ticketNumber;
	}

	public LocalTime getCheckinTime() {
		return checkinTime;
	}

	public void setCheckinTime(LocalTime checkinTime) {
		this.checkinTime = checkinTime;
	}

	public String getParkSize() {
		return parkSize;
	}

	public void setParkSize(String parkSize) {
		this.parkSize = parkSize;
	}

	public void createParker() {
		// Create new object for new customer
		Parking parker = new Parking();
		parker.ticketNumber = Manager.ticketCounter;
		parker.checkinTime = java.time.LocalTime.now();
		parker.parkSize = this.carSize;
		parkers.add(parker);
		// Print Details
		System.out.println("Your car size is: " + parker.parkSize);
		System.out.println("Your check in time is: " + parker.checkinTime);
		System.out.println("Your ticket number is: " + parker.ticketNumber);
		// Update Ticket Counter
		Manager.ticketCounter += 1;
	}

	public boolean findTicket(int ticketNumber) {
		try {
			for (Parking p : Parking.parkers) {
				if (p.getTicketNumber() == ticketNumber) {
					generateCharges(Parking.parkers.indexOf(p));
					updateParkingOnExit(Parking.parkers.indexOf(p));
					return true;
				}
				
			}
		} catch (ParseException e) {
		}
		return false;
	}

	public void generateCharges(int ticketNumber) throws ParseException {
		long total = calculateParkingDuration(ticketNumber);
		int charges;
		if (Parking.parkers.get(ticketNumber).getParkSize() == "Small")
			charges = ((int) total) * 1;
		else if (Parking.parkers.get(ticketNumber).getParkSize() == "Medium")
			charges = ((int) total) * 2;
		else
			charges = ((int) total) * 3;

		System.out.println("Checkin Time: " + checkinTime);
		System.out.println("Checkout Time: " + checkoutTime);
		System.out.println("Parking charges: " + charges + " Rupees");
	}

	public long calculateParkingDuration(int ticketNumber) {
		LocalTime t1 = (Parking.parkers.get(ticketNumber).getCheckinTime());
		LocalTime t2 = (java.time.LocalTime.now());
		checkinTime = t1;
		checkoutTime = t2;
		long diffHours = (t2.getHour() - t1.getHour()) * 3600;
		long diffMins = (t2.getMinute() - t1.getMinute()) * 60;
		long diffSeconds = t2.getSecond() - t1.getSecond();
		long total = diffHours + diffMins + diffSeconds;
		return total;
	}

	public void updateParkingOnExit(int ticketNumber) {
		// Update Parking Slots
		if (Parking.parkers.get(ticketNumber).parkSize == "Small")
			Small.countSmall += 1;
		else if (Parking.parkers.get(ticketNumber).parkSize == "Medium")
			Medium.countMedium += 1;
		else
			Large.countLarge += 1;
		// Remove car from parker's list
		Parking.parkers.remove(ticketNumber);
	}

}
