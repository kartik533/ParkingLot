package parkinglot;

import java.util.Scanner;

public class Large {

	static int countLarge;

	Scanner obj = new Scanner(System.in);
	Parking park = new Parking();

	public boolean generateTicketForLarge() {
		park.setCarSize("Large");
		if (countLarge >= 1) {
			park.createParker();
			countLarge -= 1;
			return true;
		} else
			return false;
	}
}
