package parkinglot;

import java.util.Scanner;

public class Medium {

	static int countMedium = 1;
	Scanner obj = new Scanner(System.in);
	Parking park = new Parking();
	Large large = new Large();

	public static int getCountMedium() {
		return countMedium;
	}

	public static void setCountMedium(int countMedium) {
		Medium.countMedium = countMedium;
	}

	public boolean generateTicketForMedium() {
		park.setCarSize("Medium");
		if (countMedium >= 1) {
			park.createParker();
			Medium.countMedium -= 1;
			return true;
		} else
			return false;
	}

	public void upgradeMedium() {
		if (Large.countLarge >= 1)
			large.generateTicketForLarge();
		else if (Large.countLarge < 1) {
			System.out.println("Sorry Large also full");
		}
	}
}
