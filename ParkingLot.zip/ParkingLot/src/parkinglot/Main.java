package parkinglot;

import java.text.ParseException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import parkinglot.Parking;

import java.util.Scanner;

public class Main {
	// Create Objects to access other classes
	static Parking park = new Parking();
	static Scanner obj = new Scanner(System.in);
	static Manager manager = new Manager();
	static Small small = new Small();
	static Medium med = new Medium();
	static Large large = new Large();

	public static void main(String[] args) {

		Main main = new Main();

		System.out.println("Enter number of Small Slots :");
		Small.countSmall = obj.nextInt();
		System.out.println("Enter number of Medium Slots :");
		Medium.countMedium = obj.nextInt();
		System.out.println("Enter number of Large Slots :");
		Large.countLarge = obj.nextInt();

		while (Manager.ticketCounter >= 1) {
			main.getInput();
		}
	}

	public void getInput() {
		// Get input from user
		System.out.println("Choose Option");
		System.out.println("1. Entry");
		System.out.println("2. Exit");
		int option = obj.nextInt();
		if (option == 1)
			generateTicket();
		else if (option == 2)
			processExit();
		else {
			System.out.println("Invalid Option. Please try again.");
			getInput();
		}
	}

	public void generateTicket() {
		System.out.println("Select your car Size");
		System.out.println("1. Small");
		System.out.println("2. Medium");
		System.out.println("3. Large");
		int option = obj.nextInt();
		if (option == 1)
			optionSmall();
		else if (option == 2)
			optionMedium();
		else if (option == 3)
			optionLarge();
		else
			System.out.println("Invalid Option. Please try again.");
	}

	public void processExit() {
		if (Parking.parkers.isEmpty())
			System.out.println("No cars parked.");
		else {
			System.out.println("Enter your Ticket Number :");
			int ticketNumber = obj.nextInt();
			boolean status = park.findTicket(ticketNumber);
			if (status == false)
				System.out.println("Ticket Number not found :");
		}
	}

	public void optionSmall() {
		boolean status = small.generateTicketForSmall();
		if (status == false) {
			System.out.println("Sorry Small Parking Full. Do you want to upgrade to Medium/Large ?");
			System.out.println("1. Yes");
			System.out.println("2. No");
			int option2 = obj.nextInt();
			if (option2 == 1)
				small.upgradeSmall();
			else if (option2 == 2)
				getInput();
			else {
				System.out.println("Invalid option. Please Try Again");
				optionSmall();
			}
		}
	}

	public void optionMedium() {
		boolean status = med.generateTicketForMedium();
		if (status == false) {
			System.out.println("Sorry Medium Parking Full. Do you want to upgrade to Large ?");
			System.out.println("1. Yes");
			System.out.println("2. No");
			int option2 = obj.nextInt();
			if (option2 == 1)
				med.upgradeMedium();
			else if (option2 == 2)
				getInput();
			else {
				System.out.println("Invalid option.Please Try Again");
				optionMedium();
			}
		}
	}

	public boolean optionLarge() {
		boolean status = large.generateTicketForLarge();
		if (status == false) {
			System.out.println("Sorry Parking Full");
			getInput();
		}
		return true;
	}
}
