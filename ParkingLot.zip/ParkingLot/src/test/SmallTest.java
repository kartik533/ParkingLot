package test;

import static org.junit.Assert.*;

import org.junit.Test;

import parkinglot.Main;
import parkinglot.Small;

public class SmallTest {

	@org.junit.Test
	public void testGenerateTicketForSmall() {
		Small small = new Small();
		small.generateTicketForSmall();	
	}
	
	@org.junit.Test
	public void testUpgradeSmall() {
		Small small = new Small();
		small.upgradeSmall();	
	}
	

}
