package test;

import static org.junit.Assert.*;

import org.junit.Test;

import parkinglot.Large;
import parkinglot.Medium;

public class LargeTest {

	Large large = new Large();

	@org.junit.Test
	public void testGenerateTicketForLarge() {
		large.generateTicketForLarge();
	}

}
