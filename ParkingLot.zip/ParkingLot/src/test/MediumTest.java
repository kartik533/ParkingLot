package test;

import static org.junit.Assert.*;

import org.junit.Test;

import parkinglot.Medium;
import parkinglot.Small;

public class MediumTest {

	Medium med = new Medium();

	@org.junit.Test
	public void testGenerateTicketForSmall() {
		med.generateTicketForMedium();
	}

	@org.junit.Test
	public void testUpgradeSmall() {
		med.upgradeMedium();
	}
}
