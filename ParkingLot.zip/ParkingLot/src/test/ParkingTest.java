package test;

import static org.junit.Assert.*;

import java.text.ParseException;

import org.junit.Test;

import parkinglot.Parking;

public class ParkingTest {

	Parking park = new Parking();

	@org.junit.Test
	public void testCreateParker() {
		park.createParker();
	}

	@org.junit.Test
	public void testFindTicket() {
		park.findTicket(1);
	}

//	@org.junit.Test
//	public void testGenerateCharges() throws ParseException {
//		park.generateCharges(1);
//	}
//
//	@org.junit.Test
//	public void testCalculateParkingDuration() {
//		park.calculateParkingDuration(2);
//	}
//	
//	@org.junit.Test
//	public void testUpdateParkingOnExit() {
//		park.updateParkingOnExit(3);
//	}
	
	

}
