package test;

import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;

import parkinglot.Main;

//import com.scb.retail.parkinglot.test.Test;

public class MainTest {
	
//	@org.junit.Test
//	public void testMain() {
//		Main main = new Main();
//		main.main(null);	
//	}

	@Ignore
	public void testOptionLarge() {
		Main main = new Main();
		Boolean result = main.optionLarge();
		assertEquals(true, result);
	}

	@Test
	public void testOptionMedium() {
		Main main = new Main();
		main.optionMedium();
		// assertEquals(true,result);
	}

	@Test
	public void testOptionSmall() {
		Main main = new Main();
		main.optionMedium();

	}

	@org.junit.Test
	public void testGenerateTicket() {
		Main main = new Main();
		main.generateTicket();

	}

	@org.junit.Test
	public void testProcessExit() {
		Main main = new Main();
		main.processExit();

	}

	@org.junit.Test
	public void testGetInput() {
		Main main = new Main();
		main.getInput();

	}

}
